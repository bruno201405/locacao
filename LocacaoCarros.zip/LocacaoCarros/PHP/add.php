<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("dbcontroller.php");
$db_handle = new DBController();

if (!empty($_POST["submit"])) {
    $imagem_nome = "";

    if (isset($_FILES["imagem"])) {
        if ($_FILES["imagem"]["error"] !== UPLOAD_ERR_OK) {
            die("Erro no upload da imagem: código " . $_FILES["imagem"]["error"]);
        }

        $imagem_nome = basename($_FILES["imagem"]["name"]);
        $destino = __DIR__ . "/imagens/" . $imagem_nome;

        // Verifica se a pasta existe
        // no arquivo php.ini editar os itens: upload_max_filesize = 10M, post_max_size = 10M
        // inserir imagens com tamanho máximo 10mb
        if (!is_dir(__DIR__ . "/imagens")) {
            die("A pasta 'imagens/' não existe.");
        }

        // Move a imagem para a pasta correta
        if (!move_uploaded_file($_FILES["imagem"]["tmp_name"], $destino)) {
            $erro = error_get_last();
            die("Erro ao mover a imagem: " . print_r($erro, true));
        }
    }

    $query = "INSERT INTO carros(modelo, marca, ano, placa, precodiaria, imagem) 
              VALUES('" . $_POST["modelo"] . "','" . $_POST["marca"] . "','" . $_POST["ano"] . "','" . $_POST["placa"] . "','" . $_POST["precodiaria"] . "','" . $imagem_nome . "')";
    
    $result = $db_handle->executeQuery($query);

    if (!$result) {
        $message = "Erro ao ADICIONAR. Verificar.";
    } else {
        header("Location:TelaControleAdm.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar</title>
    <link rel="stylesheet" href="TelaControleAdm.css">
    <link href="CSS/AddEditDelete.css" type="text/css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        function validate() {
            var valid = true;
            $(".demoInputBox").css('background-color', '');
            $(".info").html('');

            if (!$("#modelo").val()) {
                $("#info-modelo").html("(obrigatório)");
                $("#modelo").css('background-color', 'rgba(10, 0, 68, 0.1)');
                valid = false;
            }
            if (!$("#marca").val()) {
                $("#info-marca").html("(obrigatório)");
                $("#marca").css('background-color', 'rgba(10, 0, 68, 0.1)');
                valid = false;
            }
            if (!$("#ano").val()) {
                $("#info-ano").html("(obrigatório)");
                $("#ano").css('background-color', 'rgba(10, 0, 68, 0.1)');
                valid = false;
            }
            if (!$("#placa").val()) {
                $("#info-placa").html("(obrigatório)");
                $("#placa").css('background-color', 'rgba(10, 0, 68, 0.1)');
                valid = false;
            }
            if (!$("#precodiaria").val()) {
                $("#info-precodiaria").html("(obrigatório)");
                $("#precodiaria").css('background-color', 'rgba(10, 0, 68, 0.1)');
                valid = false;
            }

            return valid;
        }
    </script>
</head>
<body>
<div class="container">
    <div class="UpBar">
        <a href="TelaControleAdm.php" id="back">
            <i class='far fa-arrow-alt-circle-left' style='font-size:24px; margin-right: 10px;'></i>
            VOLTAR PARA TELA DE CONTROLE
        </a>
        <br><img src="YG1.png" alt="Logo">
    </div>

    <div class="form">
        <form name="frmToy" method="post" action="" id="frmToy" enctype="multipart/form-data" onsubmit="return validate();">
            <h3 id="titulo">Adicione as informações do novo produto</h3>

            <div>
                <label class="title">Modelo</label>
                <span id="info-modelo" class="info"></span><br/>
                <input type="text" name="modelo" id="modelo" class="demoInputBox" value="">
            </div>

            <div>
                <label class="title">Marca</label>
                <span id="info-marca" class="info"></span><br/>
                <input type="text" name="marca" id="marca" class="demoInputBox" value="">
            </div>

            <div>
                <label class="title">Ano</label>
                <span id="info-ano" class="info"></span><br/>
                <input type="text" name="ano" id="ano" class="demoInputBox" value="">
            </div>

            <div>
                <label class="title">Placa</label>
                <span id="info-placa" class="info"></span><br/>
                <input type="text" name="placa" id="placa" class="demoInputBox" value="">
            </div>

            <div>
                <label class="title">Preço Diária</label>
                <span id="info-precodiaria" class="info"></span><br/>
                <input type="text" name="precodiaria" id="precodiaria" class="demoInputBox" value="">
            </div>

            <div>
                <label class="title">Imagem</label>
                <span id="info-imagem" class="info"></span><br/>
                <input type="file" name="imagem" id="imagem" class="demoInputBox" accept="image/*">
            </div>

            <div>
                <input class="btnSave" type="submit" name="submit" value="Salvar" />
            </div>
        </form>
    </div>
</div>
</body>
</html>
